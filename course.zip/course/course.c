/**
 * @file course.c
 * @author Anu Kumar
 * @brief create a course.
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief 
 * This function adds a particular student to a course.
 * calloc allocates multiple blocks of memory for the values accessed by
 * course -> students. This only happens if the value of courses-> are equal to 1.
 * If this is not the case, then realloc is used to dynamincally reallocate a block of memory 
 * with size of the value of course -> total_student pointing to size of(student) 
 * 
 * @param course a pointer that represents a particular course from a collection of Courses (struct)
 * @param student a pointer that represents a specific student from a collection of Students (struct)
 * @return nothing
 */
 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief 
 * function prints out the name of the course, the course code, and the
 * total number of students. This information is accessed through the values from
 * course -> name, course -> code, etc.
 * This code also prints out information about all the individual students enrolled in the course.
 * It uses a for loop to achieve this. 
 * i keeps track of which student we are talking about and course ->total_students
 * retrieves the value of the total number of students enrolled in that course.
 * 
 * 
 * @param course represents a particular course
 * @return nothing
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) //for loop 
    print_student(&course->students[i]);
}


/**
 * @brief 
 * This function retrievs the student with the highest average
 * from the cluster. It does this by using a mixture of if statements and 
 * for loops. The forloop iterates over all the students' average.
 * 
 * @param course 
 * @return Student* 
 */

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++) //forloop intereates over the students
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief 
 * This function gathers the students who are passing the course. 
 * Calloc makes rooms for this information so all the students can be acessed
 * at the end.
 * 
 * 
 * @param course represents a specific course
 * @param total_passing represents the number of people who are passing
 * @return Student*
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) //forloop interates
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}