/**
 * @file course.h
 * @author Anu Kumar
 * @brief creates the typedef structs necessary for course.c.
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief 
 * creates a type_def structure called course
 * that holds information about the course name, the course code and information about the students. 
 * In particular it holds the collection of students who are enrolled in the course,
 * who is passing the course and who the top student is. 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief 
 * references the functions with information about a specifc course.
 * 
 * @param course represents a particular course.
 * @param student represents a particular student.
 */

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


