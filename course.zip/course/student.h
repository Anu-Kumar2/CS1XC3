/**
 * @file student.h
 * @author Anu Kumar
 * @brief header file. Creates necessary typedef structs
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief 
 * The typedef struct Student stores information about each students name, ID and grades
 * 
 */

typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief 
 * references functions pertaining to the information of each student. 
 * The struct Student will hold all this information.
 * 
 * @param student acts as an individual student
 * @param grade acts as an individual grade from a student
 */

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
