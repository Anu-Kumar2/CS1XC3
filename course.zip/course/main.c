/**
 * @file main.c
 * @author Anu Kumar 
 * @brief Displays the grades, ID and average of students enrolled in a particular class
 * @version 0.1
 * @date April 8th 2022
 * 
 *
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief 
 * The main function is run to execute the combination of all the information.
 * It holds the infomation about the course name and its code. 
 * It adds students to this course by using the function enroll_student.
 * It then prints the necessary infromation using the print_course function. 
 * It goes on to displaying the top student by using the function top_student.
 * Finally it prints out all the students who are currently passing the course using a 
 * for loop and the function passing.
 * 
 * @return int 
 */

int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]); //forloop for printing out passing students
  
  return 0;
}